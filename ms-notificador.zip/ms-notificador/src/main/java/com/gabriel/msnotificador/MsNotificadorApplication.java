package com.gabriel.msnotificador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsNotificadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsNotificadorApplication.class, args);
	}

}
